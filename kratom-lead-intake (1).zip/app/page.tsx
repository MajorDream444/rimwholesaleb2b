import LeadIntakeForm from "@/components/lead-intake-form"
import Image from "next/image"

export default function Home() {
  return (
    <div className="min-h-screen bg-gradient-to-b from-green-50 to-green-100 py-12 px-4 sm:px-6 lg:px-8">
      <div className="max-w-4xl mx-auto">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <Image
              src="/images/logo.png"
              alt="RIM Kratom Distribution"
              width={120}
              height={120}
              className="h-24 w-auto"
            />
          </div>
          <h1 className="text-3xl font-bold text-green-800 sm:text-4xl">B2B Kratom Distribution</h1>
          <p className="mt-3 text-xl text-green-600">Premium Kratom Products for Businesses Worldwide</p>
        </div>

        <div className="bg-white shadow-xl rounded-lg overflow-hidden mb-8">
          <div className="bg-green-800 p-4 text-white">
            <h2 className="text-xl font-semibold">Business Qualification Form</h2>
            <p className="text-sm opacity-90">
              Tell us about your business needs and we'll match you with the right products
            </p>
          </div>
          <LeadIntakeForm />
        </div>
      </div>
    </div>
  )
}
