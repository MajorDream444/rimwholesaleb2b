"use server"

type FormData = {
  market: string
  businessModel: string
  monthlyVolume: string
  sourcingPriority: string
  productInterests: string[]
  productTypes: string[]
  name: string
  company: string
  email: string
  estimatedVolume: string
  additionalNotes?: string
  requestSamples: boolean
  sampleRequests: SampleRequest[]
  shippingAddress: {
    addressLine1: string
    addressLine2: string
    city: string
    state: string
    postalCode: string
    country: string
    phoneNumber: string
    shippingNotes: string
    preferredShippingMethod?: string
  }
}

type SampleRequest = {
  productType: string
  quantity: string
  notes: string
}

type SampleFeedbackData = {
  leadId: string
  sampleId: string
  productType: string
  overallRating: number
  qualityRating: number
  potencyRating: number
  packagingRating: number
  wouldPurchase: string
  feedbackComments: string
  improvementSuggestions: string
  name: string
  email: string
}

// Sample request limits configuration
const SAMPLE_LIMITS = {
  maxSamplesPerLead: 5,
  maxQuantityPerSample: {
    "Fresh Leaf": "250g",
    "Dried Whole Leaf": "250g",
    "Crushed/Cut Leaf": "250g",
    "Powder (Raw)": "250g",
    "Nano/Micronized Powder": "100g",
    "Fortified/Enriched/UEI": "50g",
    "Resin/Hard Extract": "25g",
    "Standardized Extract": "25g",
    "Ratio Extracts": "25g",
    Tincture: "30ml",
    "Shot/Beverage": "2 units",
    Distillate: "5ml",
    "Isolate (Pure Mitragynine)": "5g",
    "Full-Spectrum Alkaloid Blend": "10g",
    "Capsules/Tablets": "20 units",
    "Functional Food & Topicals": "5 units",
  },
  // Limit by business model
  businessModelLimits: {
    "Established Brand": 5,
    "Herbal Manufacturer": 5,
    "Private Label": 4,
    Distributor: 5,
    Other: 3,
  },
  // Limit by monthly volume
  volumeLimits: {
    "100kg - 1 ton": 3,
    "1–10 tons": 4,
    "10–100 tons": 5,
    "100–1000 tons": 5,
    "1000–3000 tons": 5,
    "3000+ tons": 5,
  },
}

export async function submitLeadData(data: FormData) {
  try {
    // 1. Save to Airtable
    await saveToAirtable(data)

    // 2. Send email notification
    await sendEmailNotification(data)

    return { success: true }
  } catch (error) {
    console.error("Error in submitLeadData:", error)
    throw new Error("Failed to submit lead data")
  }
}

// Add a function to submit sample feedback
export async function submitSampleFeedback(data: SampleFeedbackData) {
  try {
    // In a real implementation, you would save this to your database
    console.log("Saving sample feedback:", data)

    // Send notification about the feedback
    await sendFeedbackNotification(data)

    return { success: true }
  } catch (error) {
    console.error("Error in submitSampleFeedback:", error)
    throw new Error("Failed to submit sample feedback")
  }
}

// Update the Airtable save function to include sample request information
async function saveToAirtable(data: FormData) {
  // In a real implementation, you would use your Airtable API key and base ID
  // For demonstration purposes, we're just logging the data
  console.log("Saving to Airtable:", data)

  // Determine which sales agent to assign based on market and volume
  const assignedAgent = assignSalesAgent(data)

  // Format sample requests for Airtable
  let sampleRequestsFormatted = ""
  if (data.requestSamples && data.sampleRequests.length > 0) {
    sampleRequestsFormatted = data.sampleRequests
      .map(
        (req, index) =>
          `${index + 1}. ${req.productType} - ${req.quantity}${req.notes ? ` (Notes: ${req.notes})` : ""}`,
      )
      .join("\n")
  }

  // Format shipping address for Airtable
  let shippingAddressFormatted = ""
  if (data.requestSamples) {
    shippingAddressFormatted = `${data.shippingAddress.addressLine1}
${data.shippingAddress.addressLine2 ? data.shippingAddress.addressLine2 + "\n" : ""}${data.shippingAddress.city}, ${data.shippingAddress.state} ${data.shippingAddress.postalCode}
${data.shippingAddress.country}
Phone: ${data.shippingAddress.phoneNumber}
${data.shippingAddress.preferredShippingMethod ? "Preferred Shipping: " + data.shippingAddress.preferredShippingMethod + "\n" : ""}
${data.shippingAddress.shippingNotes ? "Notes: " + data.shippingAddress.shippingNotes : ""}`
  }

  // This is where you would implement the actual Airtable API call
  // Example implementation (commented out as it requires API keys):
  /*
  const airtable = new Airtable({ apiKey: process.env.AIRTABLE_API_KEY })
  const base = airtable.base(process.env.AIRTABLE_BASE_ID)
  
  await base('B2B Leads').create([
    {
      fields: {
        'Market': data.market,
        'Business Model': data.businessModel,
        'Monthly Volume': data.monthlyVolume,
        'Sourcing Priority': data.sourcingPriority,
        'Product Interests': data.productInterests.join(', '),
        'Product Types': data.productTypes.join(', '),
        'Name': data.name,
        'Company': data.company,
        'Email': data.email,
        'Estimated Volume (kg)': data.estimatedVolume,
        'Additional Notes': data.additionalNotes || '',
        'Requested Samples': data.requestSamples ? 'Yes' : 'No',
        'Sample Requests': sampleRequestsFormatted,
        'Shipping Address': shippingAddressFormatted,
        'Preferred Shipping Method': data.shippingAddress.preferredShippingMethod || 'Not specified',
        'Assigned Agent': assignedAgent
      }
    }
  ])
  */

  return true
}

// Update the email notification function to include sample request information
async function sendEmailNotification(data: FormData) {
  // In a real implementation, you would use an email service
  // For demonstration purposes, we're just logging the email content
  const assignedAgent = assignSalesAgent(data)

  // Format sample requests for email
  let sampleRequestsText = "No samples requested"
  if (data.requestSamples && data.sampleRequests.length > 0) {
    sampleRequestsText = "Sample Requests:\n\n"
    data.sampleRequests.forEach((request, index) => {
      sampleRequestsText += `  ${index + 1}. ${request.productType} - ${request.quantity}\n`
      if (request.notes) {
        sampleRequestsText += `     Notes: ${request.notes}\n`
      }
      sampleRequestsText += "\n"
    })
  }

  // Format shipping address for email
  let shippingAddressText = ""
  if (data.requestSamples) {
    shippingAddressText = `
Shipping Address:
  ${data.shippingAddress.addressLine1}
  ${data.shippingAddress.addressLine2 ? data.shippingAddress.addressLine2 : ""}
  ${data.shippingAddress.city}, ${data.shippingAddress.state} ${data.shippingAddress.postalCode}
  ${data.shippingAddress.country}
  Phone: ${data.shippingAddress.phoneNumber}
  ${data.shippingAddress.preferredShippingMethod ? "Preferred Shipping Method: " + data.shippingAddress.preferredShippingMethod : ""}
  ${data.shippingAddress.shippingNotes ? "Notes: " + data.shippingAddress.shippingNotes : ""}
`
  }

  console.log("Sending email notification:")
  console.log(`
    Subject: New B2B Kratom Lead: ${data.company}
    
    A new B2B lead has been submitted:
    
    Company: ${data.company}
    Contact: ${data.name}
    Email: ${data.email}
    Market: ${data.market}
    Business Model: ${data.businessModel}
    Monthly Volume: ${data.monthlyVolume}
    Estimated Volume: ${data.estimatedVolume} kg
    Sourcing Priority: ${data.sourcingPriority}
    Product Interests: ${data.productInterests.join(", ")}
    Product Types: ${data.productTypes.join(", ")}
    Additional Notes: ${data.additionalNotes || "None provided"}
    
    ${sampleRequestsText}
    ${shippingAddressText}
    
    This lead has been automatically assigned to: ${assignedAgent}
    
    Please follow up within 24 hours.
  `)

  // This is where you would implement the actual email sending
  // Example implementation (commented out as it requires API keys):
  /*
  const transporter = nodemailer.createTransport({
    host: process.env.EMAIL_HOST,
    port: process.env.EMAIL_PORT,
    secure: true,
    auth: {
      user: process.env.EMAIL_USER,
      pass: process.env.EMAIL_PASSWORD,
    },
  })
  
  await transporter.sendMail({
    from: '"Kratom B2B Lead System" <leads@yourdomain.com>',
    to: `${assignedAgent.email}, sales@yourdomain.com`,
    subject: `New B2B Kratom Lead: ${data.company}`,
    text: `
      A new B2B lead has been submitted:
      
      Company: ${data.company}
      Contact: ${data.name}
      Email: ${data.email}
      Market: ${data.market}
      Business Model: ${data.businessModel}
      Monthly Volume: ${data.monthlyVolume}
      Estimated Volume: ${data.estimatedVolume} kg
      Sourcing Priority: ${data.sourcingPriority}
      Product Interests: ${data.productInterests.join(', ')}
      Product Types: ${data.productTypes.join(', ')}
      Additional Notes: ${data.additionalNotes || "None provided"}
      
      ${sampleRequestsText}
      ${shippingAddressText}
      
      This lead has been automatically assigned to: ${assignedAgent.name}
      
      Please follow up within 24 hours.
    `,
  })
  */

  return true
}

// Add a function to send notifications about sample feedback
async function sendFeedbackNotification(data: SampleFeedbackData) {
  // In a real implementation, you would use an email service
  // For demonstration purposes, we're just logging the email content

  console.log("Sending feedback notification:")
  console.log(`
    Subject: Sample Feedback Received: ${data.productType}
    
    A customer has provided feedback on a sample:
    
    Product: ${data.productType}
    Sample ID: ${data.sampleId}
    Lead ID: ${data.leadId}
    
    Ratings:
    - Overall: ${data.overallRating}/5
    - Quality: ${data.qualityRating}/5
    - Potency: ${data.potencyRating}/5
    - Packaging: ${data.packagingRating}/5
    
    Would Purchase: ${data.wouldPurchase}
    
    Positive Feedback:
    ${data.feedbackComments}
    
    Improvement Suggestions:
    ${data.improvementSuggestions}
    
    Customer Information:
    Name: ${data.name}
    Email: ${data.email}
    
    Please review this feedback and follow up with the customer if appropriate.
  `)

  return true
}

function assignSalesAgent(data: FormData) {
  // Logic to assign the appropriate sales agent based on market and volume
  // This is a simplified example - you would customize this based on your team structure

  // Ultra high volume leads go to executive team
  if (data.monthlyVolume === "1000–3000 tons" || data.monthlyVolume === "3000+ tons") {
    return "Executive Team (VP of Sales)"
  }

  // High volume leads go to senior agents
  if (data.monthlyVolume === "10–100 tons" || data.monthlyVolume === "100–1000 tons") {
    return "Sarah Johnson (Senior Account Executive)"
  }

  // Assign based on market
  switch (data.market) {
    case "United States":
      return "Michael Smith (US Market Specialist)"
    case "Europe":
      return "Anna Müller (European Market Specialist)"
    case "Asia/Pacific":
      return "David Wong (APAC Market Specialist)"
    default:
      return "Alex Rodriguez (International Markets)"
  }
}

// Add a function to check if a sample request exceeds the limits
export function checkSampleLimits(data: FormData): {
  valid: boolean
  remainingSamples: number
  message?: string
  quantityLimits: Record<string, string>
} {
  // Get the applicable limit based on business model and volume
  const businessModelLimit =
    SAMPLE_LIMITS.businessModelLimits[data.businessModel as keyof typeof SAMPLE_LIMITS.businessModelLimits] || 3
  const volumeLimit = SAMPLE_LIMITS.volumeLimits[data.monthlyVolume as keyof typeof SAMPLE_LIMITS.volumeLimits] || 3

  // Use the more generous limit
  const effectiveLimit = Math.max(businessModelLimit, volumeLimit)
  const maxSamples = Math.min(effectiveLimit, SAMPLE_LIMITS.maxSamplesPerLead)

  const remainingSamples = maxSamples - data.sampleRequests.length

  if (remainingSamples < 0) {
    return {
      valid: false,
      remainingSamples: 0,
      message: `You have exceeded the maximum of ${maxSamples} sample requests for your business type and volume.`,
      quantityLimits: SAMPLE_LIMITS.maxQuantityPerSample,
    }
  }

  // Check if any individual sample exceeds its type limit
  for (const sample of data.sampleRequests) {
    const productType = sample.productType
    const maxQuantity =
      SAMPLE_LIMITS.maxQuantityPerSample[productType as keyof typeof SAMPLE_LIMITS.maxQuantityPerSample]

    if (maxQuantity) {
      // This is a simplified check - in a real implementation, you would parse and compare quantities properly
      const requestedQuantity = sample.quantity

      // For demonstration purposes, we're just checking if the requested quantity contains a higher number
      const requestedNumber = Number.parseInt(requestedQuantity.match(/\d+/)?.[0] || "0")
      const maxNumber = Number.parseInt(maxQuantity.match(/\d+/)?.[0] || "0")

      if (requestedNumber > maxNumber) {
        return {
          valid: false,
          remainingSamples,
          message: `The requested quantity for ${productType} exceeds the maximum of ${maxQuantity}.`,
          quantityLimits: SAMPLE_LIMITS.maxQuantityPerSample,
        }
      }
    }
  }

  return {
    valid: true,
    remainingSamples,
    quantityLimits: SAMPLE_LIMITS.maxQuantityPerSample,
  }
}
