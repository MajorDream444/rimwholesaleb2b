"use client"

import { useState, useEffect } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Checkbox } from "@/components/ui/checkbox"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { submitLeadData, checkSampleLimits } from "@/app/actions"
import { CheckCircle2, ArrowRight, Loader2, Info, Package, FileText } from "lucide-react"
import ProductGlossary from "@/components/product-glossary"
import SampleFeedbackForm from "@/components/sample-feedback-form"
import SampleTracking from "@/components/sample-tracking"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

// Update the FormData type to include shipping address information
type FormData = {
  market: string
  businessModel: string
  monthlyVolume: string
  sourcingPriority: string
  productInterests: string[]
  productTypes: string[]
  name: string
  company: string
  email: string
  estimatedVolume: string
  additionalNotes: string
  requestSamples: boolean
  sampleRequests: SampleRequest[]
  // Add shipping address fields
  shippingAddress: {
    addressLine1: string
    addressLine2: string
    city: string
    state: string
    postalCode: string
    country: string
    phoneNumber: string
    shippingNotes: string
    preferredShippingMethod: string
  }
}

// Add a new type for sample requests
type SampleRequest = {
  productType: string
  quantity: string
  notes: string
}

export default function LeadIntakeForm() {
  const [step, setStep] = useState(1)
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [showGlossary, setShowGlossary] = useState(false)
  const [showFeedbackForm, setShowFeedbackForm] = useState(false)
  const [showSampleTracking, setShowSampleTracking] = useState(false)
  const [sampleLimits, setSampleLimits] = useState<{
    valid: boolean
    remainingSamples: number
    message?: string
    quantityLimits: Record<string, string>
  }>({
    valid: true,
    remainingSamples: 5,
    quantityLimits: {},
  })

  // Update the initial state to include shipping address and preferred shipping method
  const [formData, setFormData] = useState<FormData>({
    market: "",
    businessModel: "",
    monthlyVolume: "",
    sourcingPriority: "",
    productInterests: [],
    productTypes: [],
    name: "",
    company: "",
    email: "",
    estimatedVolume: "",
    additionalNotes: "",
    requestSamples: false,
    sampleRequests: [],
    shippingAddress: {
      addressLine1: "",
      addressLine2: "",
      city: "",
      state: "",
      postalCode: "",
      country: "",
      phoneNumber: "",
      shippingNotes: "",
      preferredShippingMethod: "",
    },
  })

  // Check sample limits whenever relevant form data changes
  useEffect(() => {
    if (formData.requestSamples && (formData.businessModel || formData.monthlyVolume)) {
      const checkLimits = async () => {
        const result = await checkSampleLimits(formData)
        setSampleLimits(result)
      }
      checkLimits()
    }
  }, [formData.requestSamples, formData.businessModel, formData.monthlyVolume, formData.sampleRequests])

  const updateFormData = (field: keyof FormData, value: any) => {
    setFormData((prev) => ({ ...prev, [field]: value }))
  }

  const toggleProductInterest = (value: string) => {
    setFormData((prev) => {
      const currentInterests = [...prev.productInterests]
      if (currentInterests.includes(value)) {
        return {
          ...prev,
          productInterests: currentInterests.filter((item) => item !== value),
        }
      } else {
        return {
          ...prev,
          productInterests: [...currentInterests, value],
        }
      }
    })
  }

  const toggleProductType = (value: string) => {
    setFormData((prev) => {
      const currentTypes = [...prev.productTypes]
      if (currentTypes.includes(value)) {
        return {
          ...prev,
          productTypes: currentTypes.filter((item) => item !== value),
        }
      } else {
        return {
          ...prev,
          productTypes: [...currentTypes, value],
        }
      }
    })
  }

  // Add this function after the toggleProductType function
  const addSampleRequest = () => {
    if (sampleLimits.remainingSamples <= 0) {
      return // Don't add more if limit reached
    }

    setFormData((prev) => ({
      ...prev,
      sampleRequests: [
        ...prev.sampleRequests,
        {
          productType: "",
          quantity: "",
          notes: "",
        },
      ],
    }))
  }

  const updateSampleRequest = (index: number, field: keyof SampleRequest, value: string) => {
    setFormData((prev) => {
      const updatedSampleRequests = [...prev.sampleRequests]
      updatedSampleRequests[index] = {
        ...updatedSampleRequests[index],
        [field]: value,
      }
      return {
        ...prev,
        sampleRequests: updatedSampleRequests,
      }
    })
  }

  const removeSampleRequest = (index: number) => {
    setFormData((prev) => ({
      ...prev,
      sampleRequests: prev.sampleRequests.filter((_, i) => i !== index),
    }))
  }

  // Add a function to update shipping address fields
  const updateShippingAddress = (field: keyof FormData["shippingAddress"], value: string) => {
    setFormData((prev) => ({
      ...prev,
      shippingAddress: {
        ...prev.shippingAddress,
        [field]: value,
      },
    }))
  }

  const handleNext = () => {
    if (validateCurrentStep()) {
      setStep((prev) => prev + 1)
      window.scrollTo(0, 0)
    }
  }

  const handleBack = () => {
    setStep((prev) => prev - 1)
    window.scrollTo(0, 0)
  }

  // Update the validateCurrentStep function to validate shipping address when needed
  const validateCurrentStep = () => {
    switch (step) {
      case 1:
        return !!formData.market
      case 2:
        return !!formData.businessModel
      case 3:
        return !!formData.monthlyVolume
      case 4:
        return !!formData.sourcingPriority
      case 5:
        return formData.productInterests.length > 0
      case 6:
        return formData.productTypes.length > 0
      case 7:
        return (
          !!formData.name &&
          !!formData.company &&
          !!formData.email &&
          !!formData.estimatedVolume &&
          /^[^\s@]+@[^\s@]+\.[^\s@]+$/.test(formData.email)
        )
      case 8:
        // If they don't want samples, no validation needed
        if (!formData.requestSamples) return true

        // If they want samples, validate both sample requests and shipping address
        const validSampleRequests =
          formData.sampleRequests.length > 0 &&
          formData.sampleRequests.every((req) => !!req.productType && !!req.quantity)

        const validShippingAddress =
          !!formData.shippingAddress.addressLine1 &&
          !!formData.shippingAddress.city &&
          !!formData.shippingAddress.country &&
          !!formData.shippingAddress.phoneNumber &&
          !!formData.shippingAddress.preferredShippingMethod

        return validSampleRequests && validShippingAddress && sampleLimits.valid
      default:
        return true
    }
  }

  const handleSubmit = async () => {
    if (validateCurrentStep()) {
      setIsSubmitting(true)
      try {
        await submitLeadData(formData)
        setIsSubmitted(true)
      } catch (error) {
        console.error("Error submitting form:", error)
      } finally {
        setIsSubmitting(false)
      }
    }
  }

  if (showFeedbackForm) {
    return <SampleFeedbackForm onBack={() => setShowFeedbackForm(false)} leadData={formData} />
  }

  if (showSampleTracking) {
    return <SampleTracking onBack={() => setShowSampleTracking(false)} leadData={formData} />
  }

  if (isSubmitted) {
    return (
      <Card className="p-8">
        <CardContent className="pt-6 text-center">
          <div className="flex justify-center mb-4">
            <CheckCircle2 className="h-16 w-16 text-green-500" />
          </div>
          <h2 className="text-2xl font-bold text-green-800 mb-2">Thank You!</h2>
          <p className="text-gray-600 mb-6">
            Your information has been submitted successfully. One of our specialists will contact you shortly to discuss
            your Kratom distribution needs.
          </p>

          {formData.requestSamples && formData.sampleRequests.length > 0 && (
            <div className="flex flex-col sm:flex-row justify-center gap-4 mb-6">
              <Button
                className="bg-green-600 hover:bg-green-700 flex items-center"
                onClick={() => setShowSampleTracking(true)}
              >
                <Package className="mr-2 h-4 w-4" />
                Track Your Samples
              </Button>
              <Button
                className="bg-green-600 hover:bg-green-700 flex items-center"
                onClick={() => setShowFeedbackForm(true)}
              >
                <FileText className="mr-2 h-4 w-4" />
                Submit Sample Feedback
              </Button>
            </div>
          )}

          <Button className="bg-green-600 hover:bg-green-700" onClick={() => window.location.reload()}>
            Submit Another Inquiry
          </Button>
        </CardContent>
      </Card>
    )
  }

  return (
    <div>
      <Tabs defaultValue="form" className="w-full">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="form" onClick={() => setShowGlossary(false)}>
            Lead Form
          </TabsTrigger>
          <TabsTrigger value="glossary" onClick={() => setShowGlossary(true)}>
            Product Glossary
          </TabsTrigger>
        </TabsList>
        <TabsContent value="form">
          {/* Progress indicator */}
          <div className="bg-green-800 p-4">
            <div className="flex justify-between items-center">
              {[1, 2, 3, 4, 5, 6, 7, 8].map((stepNumber) => (
                <div
                  key={stepNumber}
                  className={`h-2 rounded-full ${
                    stepNumber <= step ? "bg-green-400" : "bg-green-900"
                  } flex-1 ${stepNumber < 8 ? "mr-1" : ""}`}
                />
              ))}
            </div>
            <div className="text-white text-sm mt-2">
              Step {step} of 8:{" "}
              {step === 1
                ? "Market Served"
                : step === 2
                  ? "Business Model"
                  : step === 3
                    ? "Monthly Volume"
                    : step === 4
                      ? "Sourcing Priority"
                      : step === 5
                        ? "Product Interests"
                        : step === 6
                          ? "Product Types"
                          : step === 7
                            ? "Contact Information"
                            : "Sample Requests"}
            </div>
          </div>

          <CardContent className="p-6">
            {step === 1 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-green-800">Which market do you primarily serve?</h2>
                <RadioGroup
                  value={formData.market}
                  onValueChange={(value) => updateFormData("market", value)}
                  className="space-y-3"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="United States" id="market-us" />
                    <Label htmlFor="market-us">United States</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Europe" id="market-europe" />
                    <Label htmlFor="market-europe">Europe</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Asia/Pacific" id="market-asia" />
                    <Label htmlFor="market-asia">Asia/Pacific</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Other Regions" id="market-other" />
                    <Label htmlFor="market-other">Other Regions</Label>
                  </div>
                </RadioGroup>
              </div>
            )}

            {step === 2 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-green-800">What is your business model?</h2>
                <RadioGroup
                  value={formData.businessModel}
                  onValueChange={(value) => updateFormData("businessModel", value)}
                  className="space-y-3"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Established Brand" id="model-brand" />
                    <Label htmlFor="model-brand">Established Brand</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Herbal Manufacturer" id="model-manufacturer" />
                    <Label htmlFor="model-manufacturer">Herbal Manufacturer</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Private Label" id="model-private" />
                    <Label htmlFor="model-private">Private Label</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Distributor" id="model-distributor" />
                    <Label htmlFor="model-distributor">Distributor</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Other" id="model-other" />
                    <Label htmlFor="model-other">Other</Label>
                  </div>
                </RadioGroup>
              </div>
            )}

            {step === 3 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-green-800">What is your expected monthly volume?</h2>
                <RadioGroup
                  value={formData.monthlyVolume}
                  onValueChange={(value) => updateFormData("monthlyVolume", value)}
                  className="space-y-3"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="100kg - 1 ton" id="volume-small" />
                    <Label htmlFor="volume-small">100kg - 1 ton</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="1–10 tons" id="volume-medium" />
                    <Label htmlFor="volume-medium">1–10 tons</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="10–100 tons" id="volume-large" />
                    <Label htmlFor="volume-large">10–100 tons</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="100–1000 tons" id="volume-xlarge" />
                    <Label htmlFor="volume-xlarge">100–1000 tons</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="1000–3000 tons" id="volume-xxlarge" />
                    <Label htmlFor="volume-xxlarge">1000–3000 tons</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="3000+ tons" id="volume-xxxlarge" />
                    <Label htmlFor="volume-xxxlarge">3000+ tons</Label>
                  </div>
                </RadioGroup>
              </div>
            )}

            {step === 4 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-green-800">What is your primary sourcing priority?</h2>
                <RadioGroup
                  value={formData.sourcingPriority}
                  onValueChange={(value) => updateFormData("sourcingPriority", value)}
                  className="space-y-3"
                >
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Price" id="priority-price" />
                    <Label htmlFor="priority-price">Price</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Potency" id="priority-potency" />
                    <Label htmlFor="priority-potency">Potency</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Consistency" id="priority-consistency" />
                    <Label htmlFor="priority-consistency">Consistency</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Ethics" id="priority-ethics" />
                    <Label htmlFor="priority-ethics">Ethics</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <RadioGroupItem value="Compliance Docs" id="priority-compliance" />
                    <Label htmlFor="priority-compliance">Compliance Documentation</Label>
                  </div>
                </RadioGroup>
              </div>
            )}

            {step === 5 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-green-800">
                  Which products are you interested in? (Select all that apply)
                </h2>
                <div className="space-y-3">
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="product-raw"
                      checked={formData.productInterests.includes("Raw Leaf")}
                      onCheckedChange={() => toggleProductInterest("Raw Leaf")}
                    />
                    <Label htmlFor="product-raw">Raw Leaf</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="product-powder"
                      checked={formData.productInterests.includes("Powder")}
                      onCheckedChange={() => toggleProductInterest("Powder")}
                    />
                    <Label htmlFor="product-powder">Powder</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="product-premium"
                      checked={formData.productInterests.includes("Premium Strains")}
                      onCheckedChange={() => toggleProductInterest("Premium Strains")}
                    />
                    <Label htmlFor="product-premium">Premium Strains</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="product-extracts"
                      checked={formData.productInterests.includes("Extracts")}
                      onCheckedChange={() => toggleProductInterest("Extracts")}
                    />
                    <Label htmlFor="product-extracts">Extracts</Label>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Checkbox
                      id="product-full"
                      checked={formData.productInterests.includes("Full Range")}
                      onCheckedChange={() => toggleProductInterest("Full Range")}
                    />
                    <Label htmlFor="product-full">Full Range</Label>
                  </div>
                </div>
                <div className="mt-4 p-3 bg-green-50 rounded-md border border-green-200 flex items-start">
                  <Info className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                  <div className="text-sm text-green-800">
                    <p>
                      Need help understanding product types? Check the{" "}
                      <Button
                        variant="link"
                        className="p-0 h-auto text-green-600"
                        onClick={() => {
                          setShowGlossary(true)
                          document.querySelector('[data-value="glossary"]')?.click()
                        }}
                      >
                        Product Glossary
                      </Button>{" "}
                      tab for detailed descriptions.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {step === 6 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-green-800">
                  Which specific product types do you need? (Select all that apply)
                </h2>
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-3 border p-4 rounded-md">
                    <h3 className="font-medium text-green-700">Raw Plant</h3>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="type-fresh-leaf"
                        checked={formData.productTypes.includes("Fresh Leaf")}
                        onCheckedChange={() => toggleProductType("Fresh Leaf")}
                      />
                      <Label htmlFor="type-fresh-leaf">Fresh Leaf</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="type-dried-leaf"
                        checked={formData.productTypes.includes("Dried Whole Leaf")}
                        onCheckedChange={() => toggleProductType("Dried Whole Leaf")}
                      />
                      <Label htmlFor="type-dried-leaf">Dried Whole Leaf</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="type-crushed-leaf"
                        checked={formData.productTypes.includes("Crushed/Cut Leaf")}
                        onCheckedChange={() => toggleProductType("Crushed/Cut Leaf")}
                      />
                      <Label htmlFor="type-crushed-leaf">Crushed/Cut Leaf</Label>
                    </div>
                  </div>

                  <div className="space-y-3 border p-4 rounded-md">
                    <h3 className="font-medium text-green-700">Milled Material</h3>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="type-powder"
                        checked={formData.productTypes.includes("Powder (Raw)")}
                        onCheckedChange={() => toggleProductType("Powder (Raw)")}
                      />
                      <Label htmlFor="type-powder">Powder (Raw)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="type-nano"
                        checked={formData.productTypes.includes("Nano/Micronized Powder")}
                        onCheckedChange={() => toggleProductType("Nano/Micronized Powder")}
                      />
                      <Label htmlFor="type-nano">Nano/Micronized Powder</Label>
                    </div>
                  </div>

                  <div className="space-y-3 border p-4 rounded-md">
                    <h3 className="font-medium text-green-700">Enhanced Leaf</h3>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="type-fortified"
                        checked={formData.productTypes.includes("Fortified/Enriched/UEI")}
                        onCheckedChange={() => toggleProductType("Fortified/Enriched/UEI")}
                      />
                      <Label htmlFor="type-fortified">Fortified/Enriched/UEI</Label>
                    </div>
                  </div>

                  <div className="space-y-3 border p-4 rounded-md">
                    <h3 className="font-medium text-green-700">Resin & Semi-Solid Extracts</h3>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="type-resin"
                        checked={formData.productTypes.includes("Resin/Hard Extract")}
                        onCheckedChange={() => toggleProductType("Resin/Hard Extract")}
                      />
                      <Label htmlFor="type-resin">Resin/Hard Extract</Label>
                    </div>
                  </div>

                  <div className="space-y-3 border p-4 rounded-md">
                    <h3 className="font-medium text-green-700">Powdered Extracts</h3>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="type-standardized"
                        checked={formData.productTypes.includes("Standardized Extract")}
                        onCheckedChange={() => toggleProductType("Standardized Extract")}
                      />
                      <Label htmlFor="type-standardized">Standardized Extract</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="type-ratio"
                        checked={formData.productTypes.includes("Ratio Extracts")}
                        onCheckedChange={() => toggleProductType("Ratio Extracts")}
                      />
                      <Label htmlFor="type-ratio">Ratio Extracts</Label>
                    </div>
                  </div>

                  <div className="space-y-3 border p-4 rounded-md">
                    <h3 className="font-medium text-green-700">Liquid Extracts</h3>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="type-tincture"
                        checked={formData.productTypes.includes("Tincture")}
                        onCheckedChange={() => toggleProductType("Tincture")}
                      />
                      <Label htmlFor="type-tincture">Tincture</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="type-shot"
                        checked={formData.productTypes.includes("Shot/Beverage")}
                        onCheckedChange={() => toggleProductType("Shot/Beverage")}
                      />
                      <Label htmlFor="type-shot">Shot/Beverage</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="type-distillate"
                        checked={formData.productTypes.includes("Distillate")}
                        onCheckedChange={() => toggleProductType("Distillate")}
                      />
                      <Label htmlFor="type-distillate">Distillate</Label>
                    </div>
                  </div>

                  <div className="space-y-3 border p-4 rounded-md">
                    <h3 className="font-medium text-green-700">Purified Alkaloids</h3>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="type-isolate"
                        checked={formData.productTypes.includes("Isolate (Pure Mitragynine)")}
                        onCheckedChange={() => toggleProductType("Isolate (Pure Mitragynine)")}
                      />
                      <Label htmlFor="type-isolate">Isolate (Pure Mitragynine)</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="type-full-spectrum"
                        checked={formData.productTypes.includes("Full-Spectrum Alkaloid Blend")}
                        onCheckedChange={() => toggleProductType("Full-Spectrum Alkaloid Blend")}
                      />
                      <Label htmlFor="type-full-spectrum">Full-Spectrum Alkaloid Blend</Label>
                    </div>
                  </div>

                  <div className="space-y-3 border p-4 rounded-md">
                    <h3 className="font-medium text-green-700">Finished Goods</h3>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="type-capsules"
                        checked={formData.productTypes.includes("Capsules/Tablets")}
                        onCheckedChange={() => toggleProductType("Capsules/Tablets")}
                      />
                      <Label htmlFor="type-capsules">Capsules/Tablets</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Checkbox
                        id="type-food"
                        checked={formData.productTypes.includes("Functional Food & Topicals")}
                        onCheckedChange={() => toggleProductType("Functional Food & Topicals")}
                      />
                      <Label htmlFor="type-food">Functional Food & Topicals</Label>
                    </div>
                  </div>
                </div>
                <div className="mt-4 p-3 bg-green-50 rounded-md border border-green-200 flex items-start">
                  <Info className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
                  <div className="text-sm text-green-800">
                    <p>
                      For detailed information about each product type, including potency benchmarks and business use
                      cases, check the{" "}
                      <Button
                        variant="link"
                        className="p-0 h-auto text-green-600"
                        onClick={() => {
                          setShowGlossary(true)
                          document.querySelector('[data-value="glossary"]')?.click()
                        }}
                      >
                        Product Glossary
                      </Button>{" "}
                      tab.
                    </p>
                  </div>
                </div>
              </div>
            )}

            {step === 7 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-green-800">Contact Information</h2>
                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Full Name</Label>
                    <Input
                      id="name"
                      value={formData.name}
                      onChange={(e) => updateFormData("name", e.target.value)}
                      placeholder="Your full name"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="company">Company Name</Label>
                    <Input
                      id="company"
                      value={formData.company}
                      onChange={(e) => updateFormData("company", e.target.value)}
                      placeholder="Your company name"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="email">Business Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={formData.email}
                      onChange={(e) => updateFormData("email", e.target.value)}
                      placeholder="your.email@company.com"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="volume">Estimated Monthly Volume (kg)</Label>
                    <Input
                      id="volume"
                      type="text"
                      value={formData.estimatedVolume}
                      onChange={(e) => updateFormData("estimatedVolume", e.target.value)}
                      placeholder="e.g., 500"
                      required
                    />
                  </div>
                  <div className="space-y-2">
                    <Label htmlFor="notes">Additional Notes (Optional)</Label>
                    <textarea
                      id="notes"
                      className="flex min-h-[80px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                      value={formData.additionalNotes}
                      onChange={(e) => updateFormData("additionalNotes", e.target.value)}
                      placeholder="Any specific requirements or questions..."
                    />
                  </div>
                  <div className="flex items-center space-x-2 pt-2">
                    <Checkbox
                      id="request-samples"
                      checked={formData.requestSamples}
                      onCheckedChange={(checked) => updateFormData("requestSamples", checked === true)}
                    />
                    <Label htmlFor="request-samples" className="font-medium text-green-700">
                      I would like to request product samples
                    </Label>
                  </div>
                </div>
              </div>
            )}

            {step === 8 && (
              <div className="space-y-6">
                <h2 className="text-xl font-semibold text-green-800">Sample Requests</h2>

                {!formData.requestSamples ? (
                  <div className="p-4 bg-green-50 rounded-md text-center">
                    <p className="text-green-800">You have not requested any samples.</p>
                    <p className="text-sm text-green-600 mt-2">
                      If you'd like to request samples, please go back and check the sample request option.
                    </p>
                  </div>
                ) : (
                  <>
                    <div className="p-4 bg-green-50 rounded-md">
                      <p className="text-green-800">
                        Please specify which product samples you'd like to receive and provide your shipping address.
                        Our team will review your request and contact you to arrange shipping details.
                      </p>
                    </div>

                    {/* Sample Limits Information */}
                    <div className="border p-4 rounded-md bg-blue-50">
                      <h3 className="text-lg font-medium text-blue-800 mb-2">Sample Request Limits</h3>
                      <p className="text-sm text-blue-700 mb-2">
                        Based on your business model and volume, you can request up to{" "}
                        <span className="font-semibold">
                          {sampleLimits.remainingSamples + formData.sampleRequests.length}
                        </span>{" "}
                        samples.
                      </p>
                      <p className="text-sm text-blue-700">
                        You have <span className="font-semibold">{sampleLimits.remainingSamples}</span> sample requests
                        remaining.
                      </p>

                      {!sampleLimits.valid && sampleLimits.message && (
                        <Alert className="mt-3 bg-yellow-50 border-yellow-200">
                          <AlertTitle className="text-yellow-800">Attention</AlertTitle>
                          <AlertDescription className="text-yellow-700">{sampleLimits.message}</AlertDescription>
                        </Alert>
                      )}
                    </div>

                    <div className="space-y-6">
                      <div className="border-b pb-6">
                        <h3 className="text-lg font-medium text-green-700 mb-4">Sample Products</h3>

                        {formData.sampleRequests.length === 0 ? (
                          <div className="text-center p-6 border border-dashed border-green-300 rounded-md">
                            <p className="text-gray-500 mb-4">No sample requests added yet</p>
                            <Button
                              type="button"
                              onClick={addSampleRequest}
                              className="bg-green-600 hover:bg-green-700"
                              disabled={sampleLimits.remainingSamples <= 0}
                            >
                              Add Sample Request
                            </Button>
                          </div>
                        ) : (
                          <div className="space-y-6">
                            {formData.sampleRequests.map((request, index) => (
                              <div key={index} className="p-4 border rounded-md relative">
                                <Button
                                  type="button"
                                  variant="ghost"
                                  size="sm"
                                  className="absolute top-2 right-2 text-gray-400 hover:text-red-500"
                                  onClick={() => removeSampleRequest(index)}
                                >
                                  ×
                                </Button>

                                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                                  <div className="space-y-2">
                                    <Label htmlFor={`product-type-${index}`}>Product Type</Label>
                                    <select
                                      id={`product-type-${index}`}
                                      value={request.productType}
                                      onChange={(e) => updateSampleRequest(index, "productType", e.target.value)}
                                      className="flex h-10 w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                                      required
                                    >
                                      <option value="">Select a product type</option>
                                      <optgroup label="Raw Plant">
                                        <option value="Fresh Leaf">Fresh Leaf</option>
                                        <option value="Dried Whole Leaf">Dried Whole Leaf</option>
                                        <option value="Crushed/Cut Leaf">Crushed/Cut Leaf</option>
                                      </optgroup>
                                      <optgroup label="Milled Material">
                                        <option value="Powder (Raw)">Powder (Raw)</option>
                                        <option value="Nano/Micronized Powder">Nano/Micronized Powder</option>
                                      </optgroup>
                                      <optgroup label="Enhanced Leaf">
                                        <option value="Fortified/Enriched/UEI">Fortified/Enriched/UEI</option>
                                      </optgroup>
                                      <optgroup label="Resin & Semi-Solid Extracts">
                                        <option value="Resin/Hard Extract">Resin/Hard Extract</option>
                                      </optgroup>
                                      <optgroup label="Powdered Extracts">
                                        <option value="Standardized Extract">Standardized Extract</option>
                                        <option value="Ratio Extracts">Ratio Extracts</option>
                                      </optgroup>
                                      <optgroup label="Liquid Extracts">
                                        <option value="Tincture">Tincture</option>
                                        <option value="Shot/Beverage">Shot/Beverage</option>
                                        <option value="Distillate">Distillate</option>
                                      </optgroup>
                                      <optgroup label="Purified Alkaloids">
                                        <option value="Isolate (Pure Mitragynine)">Isolate (Pure Mitragynine)</option>
                                        <option value="Full-Spectrum Alkaloid Blend">
                                          Full-Spectrum Alkaloid Blend
                                        </option>
                                      </optgroup>
                                      <optgroup label="Finished Goods">
                                        <option value="Capsules/Tablets">Capsules/Tablets</option>
                                        <option value="Functional Food & Topicals">Functional Food & Topicals</option>
                                      </optgroup>
                                    </select>
                                  </div>

                                  <div className="space-y-2">
                                    <Label htmlFor={`quantity-${index}`}>
                                      Requested Quantity
                                      {request.productType && sampleLimits.quantityLimits[request.productType] && (
                                        <span className="text-xs text-gray-500 ml-1">
                                          (Max: {sampleLimits.quantityLimits[request.productType]})
                                        </span>
                                      )}
                                    </Label>
                                    <Input
                                      id={`quantity-${index}`}
                                      value={request.quantity}
                                      onChange={(e) => updateSampleRequest(index, "quantity", e.target.value)}
                                      placeholder="e.g., 100g, 5 units, etc."
                                      required
                                    />
                                  </div>

                                  <div className="space-y-2 md:col-span-2">
                                    <Label htmlFor={`notes-${index}`}>Special Instructions (Optional)</Label>
                                    <textarea
                                      id={`notes-${index}`}
                                      className="flex min-h-[60px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                                      value={request.notes}
                                      onChange={(e) => updateSampleRequest(index, "notes", e.target.value)}
                                      placeholder="Any specific requirements for this sample..."
                                    />
                                  </div>
                                </div>
                              </div>
                            ))}

                            <Button
                              type="button"
                              variant="outline"
                              onClick={addSampleRequest}
                              className="w-full border-dashed border-green-300 text-green-600"
                              disabled={sampleLimits.remainingSamples <= 0}
                            >
                              + Add Another Sample Request
                              {sampleLimits.remainingSamples <= 0 && " (Limit Reached)"}
                            </Button>
                          </div>
                        )}
                      </div>

                      {/* Add shipping address section */}
                      <div className="pt-2">
                        <h3 className="text-lg font-medium text-green-700 mb-4">Shipping Address</h3>
                        <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                          <div className="space-y-2 md:col-span-2">
                            <Label htmlFor="addressLine1">
                              Address Line 1 <span className="text-red-500">*</span>
                            </Label>
                            <Input
                              id="addressLine1"
                              value={formData.shippingAddress.addressLine1}
                              onChange={(e) => updateShippingAddress("addressLine1", e.target.value)}
                              placeholder="Street address, P.O. box, company name"
                              required
                            />
                          </div>

                          <div className="space-y-2 md:col-span-2">
                            <Label htmlFor="addressLine2">Address Line 2</Label>
                            <Input
                              id="addressLine2"
                              value={formData.shippingAddress.addressLine2}
                              onChange={(e) => updateShippingAddress("addressLine2", e.target.value)}
                              placeholder="Apartment, suite, unit, building, floor, etc."
                            />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="city">
                              City <span className="text-red-500">*</span>
                            </Label>
                            <Input
                              id="city"
                              value={formData.shippingAddress.city}
                              onChange={(e) => updateShippingAddress("city", e.target.value)}
                              required
                            />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="state">State/Province/Region</Label>
                            <Input
                              id="state"
                              value={formData.shippingAddress.state}
                              onChange={(e) => updateShippingAddress("state", e.target.value)}
                            />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="postalCode">Postal/ZIP Code</Label>
                            <Input
                              id="postalCode"
                              value={formData.shippingAddress.postalCode}
                              onChange={(e) => updateShippingAddress("postalCode", e.target.value)}
                            />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="country">
                              Country <span className="text-red-500">*</span>
                            </Label>
                            <Input
                              id="country"
                              value={formData.shippingAddress.country}
                              onChange={(e) => updateShippingAddress("country", e.target.value)}
                              required
                            />
                          </div>

                          <div className="space-y-2">
                            <Label htmlFor="phoneNumber">
                              Phone Number <span className="text-red-500">*</span>
                            </Label>
                            <Input
                              id="phoneNumber"
                              value={formData.shippingAddress.phoneNumber}
                              onChange={(e) => updateShippingAddress("phoneNumber", e.target.value)}
                              placeholder="For shipping carrier contact"
                              required
                            />
                          </div>

                          <div className="space-y-2 md:col-span-2">
                            <Label htmlFor="shippingNotes">Shipping Notes (Optional)</Label>
                            <textarea
                              id="shippingNotes"
                              className="flex min-h-[60px] w-full rounded-md border border-input bg-background px-3 py-2 text-sm ring-offset-background placeholder:text-muted-foreground focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-ring focus-visible:ring-offset-2 disabled:cursor-not-allowed disabled:opacity-50"
                              value={formData.shippingAddress.shippingNotes}
                              onChange={(e) => updateShippingAddress("shippingNotes", e.target.value)}
                              placeholder="Delivery instructions, business hours, etc."
                            />
                          </div>
                        </div>
                      </div>

                      {/* Preferred Shipping Method */}
                      <div className="pt-2">
                        <h3 className="text-lg font-medium text-green-700 mb-4">Preferred Shipping Method</h3>
                        <div className="space-y-2">
                          <Label htmlFor="preferredShippingMethod">Please select your preferred shipping method:</Label>
                          <Select onValueChange={(value) => updateShippingAddress("preferredShippingMethod", value)}>
                            <SelectTrigger className="w-full">
                              <SelectValue
                                placeholder="Select shipping method"
                                value={formData.shippingAddress.preferredShippingMethod}
                              />
                            </SelectTrigger>
                            <SelectContent>
                              <SelectItem value="Standard">Standard (5-7 business days)</SelectItem>
                              <SelectItem value="Express">Express (2-3 business days)</SelectItem>
                              <SelectItem value="Overnight">Overnight (Next business day)</SelectItem>
                            </SelectContent>
                          </Select>
                        </div>
                      </div>
                    </div>
                  </>
                )}
              </div>
            )}

            <div className="mt-8 flex justify-between">
              {step > 1 && (
                <Button variant="outline" onClick={handleBack}>
                  Back
                </Button>
              )}
              {step < 8 ? (
                <Button
                  className="ml-auto bg-green-600 hover:bg-green-700"
                  onClick={handleNext}
                  disabled={!validateCurrentStep()}
                >
                  Next <ArrowRight className="ml-2 h-4 w-4" />
                </Button>
              ) : (
                <Button
                  className="ml-auto bg-green-600 hover:bg-green-700"
                  onClick={handleSubmit}
                  disabled={isSubmitting || !validateCurrentStep()}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    "Submit"
                  )}
                </Button>
              )}
            </div>
          </CardContent>
        </TabsContent>
        <TabsContent value="glossary">
          <ProductGlossary />
        </TabsContent>
      </Tabs>
    </div>
  )
}
