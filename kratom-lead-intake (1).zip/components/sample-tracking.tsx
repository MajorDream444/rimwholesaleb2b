"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Package, Truck, CheckCircle, Clock, AlertCircle } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface SampleTrackingProps {
  onBack: () => void
  leadData: any
}

type SampleStatus = "requested" | "processing" | "shipped" | "delivered" | "issue"

type SampleWithTracking = {
  productType: string
  quantity: string
  status: SampleStatus
  trackingNumber?: string
  carrier?: string
  estimatedDelivery?: string
  lastUpdated?: string
  notes?: string
}

export default function SampleTracking({ onBack, leadData }: SampleTrackingProps) {
  // In a real implementation, this data would come from your backend
  const [samples, setSamples] = useState<SampleWithTracking[]>(
    leadData?.sampleRequests?.map((sample: any) => ({
      ...sample,
      status: Math.random() > 0.7 ? "shipped" : Math.random() > 0.4 ? "processing" : "requested",
      trackingNumber: Math.random() > 0.5 ? `TRK${Math.floor(Math.random() * 10000000)}` : undefined,
      carrier: Math.random() > 0.5 ? (Math.random() > 0.5 ? "FedEx" : "UPS") : undefined,
      estimatedDelivery:
        Math.random() > 0.5
          ? new Date(Date.now() + Math.random() * 10 * 24 * 60 * 60 * 1000).toLocaleDateString()
          : undefined,
      lastUpdated: new Date().toLocaleDateString(),
    })) || [],
  )

  const [trackingInput, setTrackingInput] = useState("")
  const [searchResults, setSearchResults] = useState<SampleWithTracking[]>([])

  const handleTrackingSearch = () => {
    if (!trackingInput.trim()) {
      setSearchResults([])
      return
    }

    const results = samples.filter((sample) =>
      sample.trackingNumber?.toLowerCase().includes(trackingInput.toLowerCase()),
    )
    setSearchResults(results)
  }

  const getStatusIcon = (status: SampleStatus) => {
    switch (status) {
      case "requested":
        return <Clock className="h-5 w-5 text-blue-500" />
      case "processing":
        return <Package className="h-5 w-5 text-yellow-500" />
      case "shipped":
        return <Truck className="h-5 w-5 text-purple-500" />
      case "delivered":
        return <CheckCircle className="h-5 w-5 text-green-500" />
      case "issue":
        return <AlertCircle className="h-5 w-5 text-red-500" />
    }
  }

  const getStatusText = (status: SampleStatus) => {
    switch (status) {
      case "requested":
        return "Requested"
      case "processing":
        return "Processing"
      case "shipped":
        return "Shipped"
      case "delivered":
        return "Delivered"
      case "issue":
        return "Issue Reported"
    }
  }

  const getStatusColor = (status: SampleStatus) => {
    switch (status) {
      case "requested":
        return "bg-blue-100 text-blue-800"
      case "processing":
        return "bg-yellow-100 text-yellow-800"
      case "shipped":
        return "bg-purple-100 text-purple-800"
      case "delivered":
        return "bg-green-100 text-green-800"
      case "issue":
        return "bg-red-100 text-red-800"
    }
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center mb-6">
          <Button variant="ghost" onClick={onBack} className="mr-2 p-2">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h2 className="text-xl font-semibold text-green-800">Sample Tracking</h2>
        </div>

        <div className="space-y-6">
          {/* Tracking Number Search */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-green-700">Track by Tracking Number</h3>
            <div className="flex space-x-2">
              <Input
                placeholder="Enter tracking number"
                value={trackingInput}
                onChange={(e) => setTrackingInput(e.target.value)}
              />
              <Button onClick={handleTrackingSearch} className="bg-green-600 hover:bg-green-700">
                Track
              </Button>
            </div>

            {searchResults.length > 0 && (
              <div className="mt-4 space-y-4">
                <h4 className="font-medium">Search Results:</h4>
                {searchResults.map((sample, index) => (
                  <div key={index} className="border rounded-md p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h5 className="font-medium">{sample.productType}</h5>
                        <p className="text-sm text-gray-500">Quantity: {sample.quantity}</p>
                      </div>
                      <Badge className={getStatusColor(sample.status)}>
                        {getStatusIcon(sample.status)}
                        <span className="ml-1">{getStatusText(sample.status)}</span>
                      </Badge>
                    </div>

                    {sample.trackingNumber && (
                      <div className="mt-3 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-500">Tracking Number:</span>
                          <span className="font-medium">{sample.trackingNumber}</span>
                        </div>
                        {sample.carrier && (
                          <div className="flex justify-between">
                            <span className="text-gray-500">Carrier:</span>
                            <span>{sample.carrier}</span>
                          </div>
                        )}
                        {sample.estimatedDelivery && (
                          <div className="flex justify-between">
                            <span className="text-gray-500">Estimated Delivery:</span>
                            <span>{sample.estimatedDelivery}</span>
                          </div>
                        )}
                        {sample.lastUpdated && (
                          <div className="flex justify-between">
                            <span className="text-gray-500">Last Updated:</span>
                            <span>{sample.lastUpdated}</span>
                          </div>
                        )}
                      </div>
                    )}
                  </div>
                ))}
              </div>
            )}
          </div>

          {/* All Samples */}
          <div className="space-y-4 border-t pt-6">
            <h3 className="text-lg font-medium text-green-700">All Sample Requests</h3>

            {samples.length > 0 ? (
              <div className="space-y-4">
                {samples.map((sample, index) => (
                  <div key={index} className="border rounded-md p-4">
                    <div className="flex justify-between items-start">
                      <div>
                        <h5 className="font-medium">{sample.productType}</h5>
                        <p className="text-sm text-gray-500">Quantity: {sample.quantity}</p>
                      </div>
                      <Badge className={getStatusColor(sample.status)}>
                        {getStatusIcon(sample.status)}
                        <span className="ml-1">{getStatusText(sample.status)}</span>
                      </Badge>
                    </div>

                    {sample.trackingNumber && (
                      <div className="mt-3 text-sm">
                        <div className="flex justify-between">
                          <span className="text-gray-500">Tracking Number:</span>
                          <span className="font-medium">{sample.trackingNumber}</span>
                        </div>
                        {sample.carrier && (
                          <div className="flex justify-between">
                            <span className="text-gray-500">Carrier:</span>
                            <span>{sample.carrier}</span>
                          </div>
                        )}
                        {sample.estimatedDelivery && (
                          <div className="flex justify-between">
                            <span className="text-gray-500">Estimated Delivery:</span>
                            <span>{sample.estimatedDelivery}</span>
                          </div>
                        )}
                        {sample.lastUpdated && (
                          <div className="flex justify-between">
                            <span className="text-gray-500">Last Updated:</span>
                            <span>{sample.lastUpdated}</span>
                          </div>
                        )}
                      </div>
                    )}

                    {sample.status === "requested" && (
                      <div className="mt-3 text-sm text-gray-500">
                        Your sample request is being reviewed. We'll update you when it's processed.
                      </div>
                    )}

                    {sample.status === "processing" && (
                      <div className="mt-3 text-sm text-gray-500">
                        Your sample is being prepared for shipment. Tracking information will be available soon.
                      </div>
                    )}
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500">No sample requests found.</p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
