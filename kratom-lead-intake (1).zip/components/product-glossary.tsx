import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Accordion, AccordionContent, AccordionItem, AccordionTrigger } from "@/components/ui/accordion"
import { Card, CardContent } from "@/components/ui/card"
import { BookOpen, Info } from "lucide-react"

export default function ProductGlossary() {
  return (
    <div className="p-6 space-y-8">
      <div className="flex items-center justify-center mb-6">
        <BookOpen className="h-6 w-6 text-green-600 mr-2" />
        <h2 className="text-2xl font-bold text-green-800">Kratom Product Glossary</h2>
      </div>

      <p className="text-gray-600 mb-6">
        This glossary explains common terms used in the Kratom industry and what they actually mean, including typical
        potency benchmarks and business use cases.
      </p>

      <Accordion type="single" collapsible className="w-full">
        <AccordionItem value="raw-plant">
          <AccordionTrigger className="text-lg font-medium text-green-700">Raw Plant</AccordionTrigger>
          <AccordionContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Term(s) You'll Hear</TableHead>
                  <TableHead>What It Actually Is</TableHead>
                  <TableHead>Typical Potency Benchmarks</TableHead>
                  <TableHead>Notes / Business Use-Case</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">Fresh Leaf</TableCell>
                  <TableCell>Leaves picked straight from the Mitragyna speciosa tree.</TableCell>
                  <TableCell>0.8 – 1.5% mitragynine (variable)</TableCell>
                  <TableCell>Perishable, local Thai/Indo market; rarely exported.</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Dried Whole Leaf</TableCell>
                  <TableCell>Sun- or oven-dried, still intact.</TableCell>
                  <TableCell>0.8 – 2%</TableCell>
                  <TableCell>Used for traditional tea decoctions or further milling.</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Crushed / Cut Leaf</TableCell>
                  <TableCell>Leaf chopped into small flakes.</TableCell>
                  <TableCell>Same as dried leaf</TableCell>
                  <TableCell>Popular for teabags or "smoking blend" markets.</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="milled-material">
          <AccordionTrigger className="text-lg font-medium text-green-700">Milled Material</AccordionTrigger>
          <AccordionContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Term(s) You'll Hear</TableHead>
                  <TableHead>What It Actually Is</TableHead>
                  <TableHead>Typical Potency Benchmarks</TableHead>
                  <TableHead>Notes / Business Use-Case</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">Powder (AKA "raw powder")</TableCell>
                  <TableCell>Leaf finely milled to talc-like powder.</TableCell>
                  <TableCell>0.8 – 2%</TableCell>
                  <TableCell>Global bulk commodity; basis for caps, tablets, drinks.</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Nano / Micronized Powder</TableCell>
                  <TableCell>Powder sieved &lt;45 μm for faster suspension.</TableCell>
                  <TableCell>Same potency</TableCell>
                  <TableCell>Smoother mouth-feel, dissolves better in beverages.</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="enhanced-leaf">
          <AccordionTrigger className="text-lg font-medium text-green-700">Enhanced Leaf</AccordionTrigger>
          <AccordionContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Term(s) You'll Hear</TableHead>
                  <TableHead>What It Actually Is</TableHead>
                  <TableHead>Typical Potency Benchmarks</TableHead>
                  <TableHead>Notes / Business Use-Case</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">Fortified / Enriched / UEI (Ultra-Enhanced Indo)</TableCell>
                  <TableCell>Raw powder coated or blended with extract.</TableCell>
                  <TableCell>5 – 20%+ (labelled)</TableCell>
                  <TableCell>Gives leaf mouth-feel but extract punch; premium pricing.</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="resin-extracts">
          <AccordionTrigger className="text-lg font-medium text-green-700">
            Resin & Semi-Solid Extracts
          </AccordionTrigger>
          <AccordionContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Term(s) You'll Hear</TableHead>
                  <TableHead>What It Actually Is</TableHead>
                  <TableHead>Typical Potency Benchmarks</TableHead>
                  <TableHead>Notes / Business Use-Case</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">Resin / "Hard Extract" / 10×, 20× Bars</TableCell>
                  <TableCell>Low-moisture tar-like mass produced by evaporating water/alcohol extract.</TableCell>
                  <TableCell>Usually expressed as "10×" etc. (misleading but common)</TableCell>
                  <TableCell>Sold by the gram; easier to ship than liquids.</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="powdered-extracts">
          <AccordionTrigger className="text-lg font-medium text-green-700">Powdered Extracts</AccordionTrigger>
          <AccordionContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Term(s) You'll Hear</TableHead>
                  <TableHead>What It Actually Is</TableHead>
                  <TableHead>Typical Potency Benchmarks</TableHead>
                  <TableHead>Notes / Business Use-Case</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">Standardized Extract</TableCell>
                  <TableCell>Spray- or drum-dried; mitragynine content declared (e.g., 10%, 30%, 65%).</TableCell>
                  <TableCell>10%–70% MIT</TableCell>
                  <TableCell>Your MIT 50-75% skus live here.</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Ratio Extracts (e.g., 10:1, 20:1)</TableCell>
                  <TableCell>Claims "10 kg leaf → 1 kg extract." Potency can vary widely.</TableCell>
                  <TableCell>Not standardized; buyer beware</TableCell>
                  <TableCell>Ask for % MIT COA, not just the ratio.</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="liquid-extracts">
          <AccordionTrigger className="text-lg font-medium text-green-700">Liquid Extracts</AccordionTrigger>
          <AccordionContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Term(s) You'll Hear</TableHead>
                  <TableHead>What It Actually Is</TableHead>
                  <TableHead>Typical Potency Benchmarks</TableHead>
                  <TableHead>Notes / Business Use-Case</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">Tincture</TableCell>
                  <TableCell>Leaf/extract soaked in ethanol/glycerin; bottled dropper format.</TableCell>
                  <TableCell>2 – 10 mg MIT per mL (varies)</TableCell>
                  <TableCell>Consumer ready; popular in head shops.</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Shot / Beverage</TableCell>
                  <TableCell>Concentrated liquid with flavor + preservatives.</TableCell>
                  <TableCell>50 – 150 mg MIT per 2-oz shot</TableCell>
                  <TableCell>Retail convenience stores in US.</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Distillate (rare)</TableCell>
                  <TableCell>Vacuum-distilled alkaloid fraction.</TableCell>
                  <TableCell>80%+ MIT</TableCell>
                  <TableCell>Niche; tech-heavy, pricey.</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="purified-alkaloids">
          <AccordionTrigger className="text-lg font-medium text-green-700">Purified Alkaloids</AccordionTrigger>
          <AccordionContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Term(s) You'll Hear</TableHead>
                  <TableHead>What It Actually Is</TableHead>
                  <TableHead>Typical Potency Benchmarks</TableHead>
                  <TableHead>Notes / Business Use-Case</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">Isolate (Pure Mitragynine)</TableCell>
                  <TableCell>≥ 95% single compound.</TableCell>
                  <TableCell>95 – 99%</TableCell>
                  <TableCell>Pharmaceutical research, regulatory hurdles.</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Full-Spectrum Alkaloid Blend</TableCell>
                  <TableCell>Combined purified alkaloids (MIT, 7-OH-MIT, speciogynine, etc.).</TableCell>
                  <TableCell>Declared per alkaloid</TableCell>
                  <TableCell>Mimics natural profile without plant solids.</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </AccordionContent>
        </AccordionItem>

        <AccordionItem value="finished-goods">
          <AccordionTrigger className="text-lg font-medium text-green-700">Finished Goods</AccordionTrigger>
          <AccordionContent>
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Term(s) You'll Hear</TableHead>
                  <TableHead>What It Actually Is</TableHead>
                  <TableHead>Typical Potency Benchmarks</TableHead>
                  <TableHead>Notes / Business Use-Case</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                <TableRow>
                  <TableCell className="font-medium">Capsules / Tablets</TableCell>
                  <TableCell>Raw powder or extract packed in caps or pressed tablets.</TableCell>
                  <TableCell>Mirrors input material</TableCell>
                  <TableCell>E-commerce staple; subject to GMP labeling.</TableCell>
                </TableRow>
                <TableRow>
                  <TableCell className="font-medium">Functional Food & Topicals</TableCell>
                  <TableCell>Gummies, chocolates, creams.</TableCell>
                  <TableCell>Depends on recipe</TableCell>
                  <TableCell>Emerging SKUs; need food-grade compliant extracts.</TableCell>
                </TableRow>
              </TableBody>
            </Table>
          </AccordionContent>
        </AccordionItem>
      </Accordion>

      <Card className="mt-8">
        <CardContent className="pt-6">
          <h3 className="text-lg font-semibold text-green-700 mb-4">Quick Cheat Codes for Conversations</h3>
          <ul className="space-y-2 list-disc pl-5">
            <li>"Leaf" → any raw, crushed, or powdered plant material ≤ 2% MIT.</li>
            <li>"Powder" by itself ≠ extract; always ask "standard raw or standardized extract?"</li>
            <li>"x% Extract" → standardized, COA should list MIT mg/g.</li>
            <li>"10× / 20× Extract" → marketing ratio; demand COA.</li>
            <li>"Isolate" → ≥ 95% single alkaloid (often regulated as a novel substance).</li>
            <li>"Enhanced Leaf" = raw powder + extract, potency anywhere 5 – 20%+.</li>
          </ul>
        </CardContent>
      </Card>

      <Card className="mt-4">
        <CardContent className="pt-6">
          <h3 className="text-lg font-semibold text-green-700 mb-4">Why This Matters for Your Sales Flow</h3>
          <ol className="space-y-2 list-decimal pl-5">
            <li>
              <span className="font-medium">Pricing Logic</span> – Cost jumps exponentially once you cross ~30% MIT
              because yield drops and purification steps increase.
            </li>
            <li>
              <span className="font-medium">Regulatory Flags</span> – Some U.S. states treat isolates/distillates
              differently from leaf or &lt; 2% extracts.
            </li>
            <li>
              <span className="font-medium">COA Discipline</span> – Always quote % w/w of mitragynine (and 7-OH if
              possible). Ratios alone are marketing fluff.
            </li>
            <li>
              <span className="font-medium">Contract Clarity</span> – In LOIs and invoices, specify both form (e.g.,
              "spray-dried powder extract") and MIT % so there's no ambiguity.
            </li>
          </ol>
        </CardContent>
      </Card>

      <div className="mt-6 p-4 bg-green-50 rounded-md border border-green-200">
        <div className="flex items-start">
          <Info className="h-5 w-5 text-green-600 mr-2 mt-0.5" />
          <div>
            <h4 className="font-medium text-green-800">Next step?</h4>
            <p className="text-sm text-green-700 mt-1">
              Let us know which forms you plan to list on your product sheet first (leaf vs. standardized extract vs.
              enhanced powder), and we can draft consistent SKUs and spec lines for your buyers.
            </p>
          </div>
        </div>
      </div>
    </div>
  )
}
