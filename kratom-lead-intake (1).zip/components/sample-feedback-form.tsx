"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { RadioGroup, RadioGroupItem } from "@/components/ui/radio-group"
import { Textarea } from "@/components/ui/textarea"
import { CheckCircle2, ArrowLeft, Loader2, Star } from "lucide-react"
import { submitSampleFeedback } from "@/app/actions"

type SampleFeedbackData = {
  leadId: string
  sampleId: string
  productType: string
  overallRating: number
  qualityRating: number
  potencyRating: number
  packagingRating: number
  wouldPurchase: string
  feedbackComments: string
  improvementSuggestions: string
  name: string
  email: string
}

interface SampleFeedbackFormProps {
  onBack: () => void
  leadData: any
}

export default function SampleFeedbackForm({ onBack, leadData }: SampleFeedbackFormProps) {
  const [isSubmitting, setIsSubmitting] = useState(false)
  const [isSubmitted, setIsSubmitted] = useState(false)
  const [selectedSample, setSelectedSample] = useState("")

  const [feedbackData, setFeedbackData] = useState<SampleFeedbackData>({
    leadId: "auto-generated", // Would be populated from the database in a real implementation
    sampleId: "",
    productType: "",
    overallRating: 0,
    qualityRating: 0,
    potencyRating: 0,
    packagingRating: 0,
    wouldPurchase: "",
    feedbackComments: "",
    improvementSuggestions: "",
    name: leadData?.name || "",
    email: leadData?.email || "",
  })

  const updateFeedbackData = (field: keyof SampleFeedbackData, value: any) => {
    setFeedbackData((prev) => ({ ...prev, [field]: value }))
  }

  const handleSampleSelect = (sampleRequest: any) => {
    setSelectedSample(sampleRequest.productType)
    updateFeedbackData("productType", sampleRequest.productType)
    updateFeedbackData("sampleId", `sample-${Math.random().toString(36).substring(2, 9)}`) // Mock ID
  }

  const handleSubmit = async () => {
    setIsSubmitting(true)
    try {
      // In a real implementation, this would send the feedback to your backend
      await submitSampleFeedback(feedbackData)
      setIsSubmitted(true)
    } catch (error) {
      console.error("Error submitting feedback:", error)
    } finally {
      setIsSubmitting(false)
    }
  }

  const StarRating = ({
    rating,
    setRating,
    name,
  }: { rating: number; setRating: (value: number) => void; name: string }) => {
    return (
      <div className="flex items-center space-x-1">
        {[1, 2, 3, 4, 5].map((star) => (
          <button
            key={star}
            type="button"
            onClick={() => setRating(star)}
            className={`focus:outline-none ${star <= rating ? "text-yellow-400" : "text-gray-300"}`}
            aria-label={`Rate ${star} out of 5`}
          >
            <Star className="h-6 w-6 fill-current" />
          </button>
        ))}
      </div>
    )
  }

  if (isSubmitted) {
    return (
      <Card className="p-8">
        <CardContent className="pt-6 text-center">
          <div className="flex justify-center mb-4">
            <CheckCircle2 className="h-16 w-16 text-green-500" />
          </div>
          <h2 className="text-2xl font-bold text-green-800 mb-2">Thank You for Your Feedback!</h2>
          <p className="text-gray-600 mb-6">
            Your feedback is invaluable to us and will help us improve our products and services.
          </p>
          <div className="flex flex-col sm:flex-row justify-center gap-4">
            <Button className="bg-green-600 hover:bg-green-700" onClick={onBack}>
              Return to Lead Form
            </Button>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <Card>
      <CardContent className="p-6">
        <div className="flex items-center mb-6">
          <Button variant="ghost" onClick={onBack} className="mr-2 p-2">
            <ArrowLeft className="h-5 w-5" />
          </Button>
          <h2 className="text-xl font-semibold text-green-800">Sample Feedback Form</h2>
        </div>

        <div className="space-y-6">
          {/* Sample Selection */}
          <div className="space-y-4">
            <h3 className="text-lg font-medium text-green-700">Select Sample to Review</h3>
            {leadData?.sampleRequests && leadData.sampleRequests.length > 0 ? (
              <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                {leadData.sampleRequests.map((sample: any, index: number) => (
                  <div
                    key={index}
                    className={`p-3 border rounded-md cursor-pointer ${
                      selectedSample === sample.productType ? "border-green-500 bg-green-50" : ""
                    }`}
                    onClick={() => handleSampleSelect(sample)}
                  >
                    <div className="font-medium">{sample.productType}</div>
                    <div className="text-sm text-gray-500">Quantity: {sample.quantity}</div>
                  </div>
                ))}
              </div>
            ) : (
              <p className="text-gray-500">No samples found to review.</p>
            )}
          </div>

          {selectedSample && (
            <>
              {/* Rating Section */}
              <div className="space-y-4 border-t pt-6">
                <h3 className="text-lg font-medium text-green-700">Product Ratings</h3>

                <div className="space-y-6">
                  <div className="space-y-2">
                    <Label>Overall Rating</Label>
                    <StarRating
                      rating={feedbackData.overallRating}
                      setRating={(value) => updateFeedbackData("overallRating", value)}
                      name="overall"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Quality Rating</Label>
                    <StarRating
                      rating={feedbackData.qualityRating}
                      setRating={(value) => updateFeedbackData("qualityRating", value)}
                      name="quality"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Potency Rating</Label>
                    <StarRating
                      rating={feedbackData.potencyRating}
                      setRating={(value) => updateFeedbackData("potencyRating", value)}
                      name="potency"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label>Packaging Rating</Label>
                    <StarRating
                      rating={feedbackData.packagingRating}
                      setRating={(value) => updateFeedbackData("packagingRating", value)}
                      name="packaging"
                    />
                  </div>
                </div>
              </div>

              {/* Would Purchase */}
              <div className="space-y-4 border-t pt-6">
                <h3 className="text-lg font-medium text-green-700">Purchase Intent</h3>
                <div className="space-y-2">
                  <Label>Would you purchase this product for your business?</Label>
                  <RadioGroup
                    value={feedbackData.wouldPurchase}
                    onValueChange={(value) => updateFeedbackData("wouldPurchase", value)}
                    className="space-y-3"
                  >
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="Definitely" id="purchase-definitely" />
                      <Label htmlFor="purchase-definitely">Definitely</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="Likely" id="purchase-likely" />
                      <Label htmlFor="purchase-likely">Likely</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="Unsure" id="purchase-unsure" />
                      <Label htmlFor="purchase-unsure">Unsure</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="Unlikely" id="purchase-unlikely" />
                      <Label htmlFor="purchase-unlikely">Unlikely</Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <RadioGroupItem value="Definitely Not" id="purchase-definitely-not" />
                      <Label htmlFor="purchase-definitely-not">Definitely Not</Label>
                    </div>
                  </RadioGroup>
                </div>
              </div>

              {/* Feedback Comments */}
              <div className="space-y-4 border-t pt-6">
                <h3 className="text-lg font-medium text-green-700">Detailed Feedback</h3>

                <div className="space-y-4">
                  <div className="space-y-2">
                    <Label htmlFor="feedback-comments">What did you like about this product?</Label>
                    <Textarea
                      id="feedback-comments"
                      value={feedbackData.feedbackComments}
                      onChange={(e) => updateFeedbackData("feedbackComments", e.target.value)}
                      placeholder="Please share your thoughts on the product quality, potency, aroma, etc."
                      className="min-h-[100px]"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="improvement-suggestions">How could we improve this product?</Label>
                    <Textarea
                      id="improvement-suggestions"
                      value={feedbackData.improvementSuggestions}
                      onChange={(e) => updateFeedbackData("improvementSuggestions", e.target.value)}
                      placeholder="Please share any suggestions for improvement"
                      className="min-h-[100px]"
                    />
                  </div>
                </div>
              </div>

              {/* Contact Information */}
              <div className="space-y-4 border-t pt-6">
                <h3 className="text-lg font-medium text-green-700">Your Information</h3>

                <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label htmlFor="name">Name</Label>
                    <Input
                      id="name"
                      value={feedbackData.name}
                      onChange={(e) => updateFeedbackData("name", e.target.value)}
                      placeholder="Your name"
                    />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="email">Email</Label>
                    <Input
                      id="email"
                      type="email"
                      value={feedbackData.email}
                      onChange={(e) => updateFeedbackData("email", e.target.value)}
                      placeholder="Your email"
                    />
                  </div>
                </div>
              </div>

              {/* Submit Button */}
              <div className="pt-6">
                <Button
                  className="w-full bg-green-600 hover:bg-green-700"
                  onClick={handleSubmit}
                  disabled={isSubmitting || !feedbackData.overallRating}
                >
                  {isSubmitting ? (
                    <>
                      <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                      Submitting...
                    </>
                  ) : (
                    "Submit Feedback"
                  )}
                </Button>
              </div>
            </>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
